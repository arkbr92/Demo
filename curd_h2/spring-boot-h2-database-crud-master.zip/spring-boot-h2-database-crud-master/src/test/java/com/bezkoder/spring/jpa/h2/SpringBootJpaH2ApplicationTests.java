package com.bezkoder.spring.jpa.h2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaH2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
